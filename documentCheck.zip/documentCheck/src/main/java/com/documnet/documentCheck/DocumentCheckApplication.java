package com.documnet.documentCheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentCheckApplication.class, args);
	}

}
